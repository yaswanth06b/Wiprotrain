import React from "react";
import PaymentList from "../Components/PaymentList";


export default function PaymentsPage() {
  return (
    <div>
      <h1>Payments</h1>
      <PaymentList />
    </div>
  );
}