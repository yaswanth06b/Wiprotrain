import React, { useEffect, useState } from "react";
import { getSubmissions } from "../Services/submissionService";

export default function SubmissionList() {
  const [subs, setSubs] = useState([]);

  useEffect(() => {
    load();
  }, []);

  async function load() {
    const data = await getSubmissions();
    setSubs(data);
  }

  return (
    <div>
      <h2>Submissions</h2>
      <ul>
        {subs.map((s) => (
          <li key={s.submissionID}>
            Assignment {s.assignmentID} by User {s.userId} — Grade: {s.grade ?? "Pending"}
          </li>
        ))}
      </ul>
    </div>
  );
}