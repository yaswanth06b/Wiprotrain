import React, { useEffect, useState } from "react";
import { getPayments } from "../Services/paymentService";

export default function PaymentList() {
  const [payments, setPayments] = useState([]);

  useEffect(() => {
    load();
  }, []);

  async function load() {
    const data = await getPayments();
    setPayments(data);
  }

  return (
    <div>
      <h2>Payments</h2>
      <ul>
        {payments.map((p) => (
          <li key={p.paymentId}>
            Student {p.studentID}, Course {p.courseID}, {p.amount} {p.currency} — {p.status}
          </li>
        ))}
      </ul>
    </div>
  );
}