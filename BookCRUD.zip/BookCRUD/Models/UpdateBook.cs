﻿namespace BookCRUD.Models
{
    public class UpdateBook
    {
        public string? Title { get; set; }
        public int AuthorId { get; set; }
    }
}
