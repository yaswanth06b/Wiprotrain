﻿using Microsoft.AspNetCore.Mvc;
using PMS.Models;

namespace PMS.Controllers
{
    public class ProductController : Controller
    {
        // Static in-memory product list
        private static List<Product> _products = new List<Product>
        {
            new Product { Id = 1, Name = "Laptop", Price = 60000 },
            new Product { Id = 2, Name = "Mobile", Price = 25000 },
            new Product { Id = 3, Name = "Tablet", Price = 30000 }
        };

        // GET: Product List
        public IActionResult ProductList()
        {
            return View(_products);
        }

        // GET: Create Product
        public IActionResult CreateProduct()
        {
            return View();
        }

        // POST: Create Product
        [HttpPost]
        public IActionResult CreateProduct(Product product)
        {
            if (ModelState.IsValid)
            {
                product.Id = _products.Max(p => p.Id) + 1;
                _products.Add(product);
                TempData["Message"] = $"Product \"{product.Name}\" has been successfully created!";
                return RedirectToAction("ProductList");
            }
            return View(product);
        }

        // GET: Edit Product
        public IActionResult EditProduct(int id)
        {
            var product = _products.FirstOrDefault(p => p.Id == id);
            if (product == null) return NotFound();
            return View(product);
        }

        // POST: Edit Product
        [HttpPost]
        public IActionResult EditProduct(Product product)
        {
            var existing = _products.FirstOrDefault(p => p.Id == product.Id);
            if (existing != null)
            {
                existing.Name = product.Name;
                existing.Price = product.Price;
                TempData["Message"] = $"Product \"{product.Name}\" has been successfully updated!";
                return RedirectToAction("ProductList");
            }
            return View(product);
        }

        // GET: Delete Product
        public IActionResult Delete(int id)
        {
            if (User.IsInRole("Admin"))
            {
                var product = _products.FirstOrDefault(p => p.Id == id);
                if (product != null)
                {
                    _products.Remove(product);
                    TempData["Message"] = $"Product \"{product.Name}\" has been deleted!";
                }
                return RedirectToAction("ProductList");
            }
            else
            {
                TempData["Message"] = "Access Denied: You do not have permission to delete products.";
                return RedirectToAction("ProductList");
            }
        }
    }
}
