﻿namespace PrepTestMVC.ViewModel
{
    public class LoginViewModel
    {
        public string username { get; set; }

        public string password { get; set; }
    }
}
