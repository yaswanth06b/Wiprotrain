﻿namespace OLMS.DTO
{
    public class CourseDto
    {
        public string Title { get; set; }
        public string Description { get; set; }
        public string Category { get; set; }
        public string Difficulty { get; set; }
        public int InstructorID { get; set; }
    }
}
