import React from "react";
import SubmissionList from "../Components/SubmissionList";

export default function SubmissionsPage() {
  return (
    <div>
      <h1>Submissions</h1>
      <SubmissionList />
    </div>
  );
}