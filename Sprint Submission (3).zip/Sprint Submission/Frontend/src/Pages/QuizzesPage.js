import React, { useState } from "react";
import QuizList from "../Components/QuizList";
import "./QuizzesPage.css";

export default function QuizzesPage() {
  const [editingQuiz, setEditingQuiz] = useState(null);
  const [showForm, setShowForm] = useState(false);

  const handleEdit = (quiz) => {
    setEditingQuiz(quiz);
    setShowForm(true);
  };

  const handleNewQuiz = () => {
    setEditingQuiz(null);
    setShowForm(true);
  };

  const handleFormClose = () => {
    setShowForm(false);
    setEditingQuiz(null);
  };

  return (
    <div className="quizzes-page">
      {/* Header */}
      <div className="quizzes-header">
        <h1>📚 Quizzes</h1>
        <button className="new-quiz-btn" onClick={handleNewQuiz}>
          + New Quiz
        </button>
      </div>

      {/* Quiz List */}
      <QuizList onEdit={handleEdit} />

      {/* Optional Modal for Add/Edit */}
      {/* {showForm && (
        <QuizForm
          quiz={editingQuiz}
          onClose={handleFormClose}
          onSaved={handleFormClose}
        />
      )} */}
    </div>
  );
}
