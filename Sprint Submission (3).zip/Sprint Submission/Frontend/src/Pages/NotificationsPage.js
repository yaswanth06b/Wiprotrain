import React from "react";
import NotificationList from "../Components/NotificationList";


export default function NotificationsPage() {
  return (
    <div>
      <h1>Notifications</h1>
      <NotificationList />
    </div>
  );
}