import axios from "axios";

// Create Axios instance
export const API = axios.create({
  baseURL: "https://localhost:7269/api",
});

// Add JWT token to request headers
API.interceptors.request.use((req) => {
  const token = localStorage.getItem("lms.jwt");
  if (token) {
    req.headers.Authorization = `Bearer ${token}`;
  }
  return req;
});

//
// ---------- AUTH ----------
export const login = async (data) => {
  const res = await API.post("/Auth/login", data);
  return res.data;
};

export const register = async (data) => {
  const res = await API.post("/Auth/register", data);
  return res.data;
};

//
// ---------- COURSES ----------
export const getCourses = async () => (await API.get("/courses")).data;
export const addCourse = async (payload) => (await API.post("/courses", payload)).data;
export const updateCourse = async (id, payload) => (await API.put(`/courses/${id}`, payload)).data;
export const deleteCourse = async (id) => (await API.delete(`/courses/${id}`)).data;

//
// ---------- ASSIGNMENTS ----------
export const getAssignments = async () => (await API.get("/assignments")).data;
export const addAssignment = async (data) => (await API.post("/assignments", data)).data;
export const updateAssignment = async (id, data) => (await API.put(`/assignments/${id}`, data)).data;
export const deleteAssignment = async (id) => (await API.delete(`/assignments/${id}`)).data;

//
// ---------- QUIZZES ----------
export const getQuizzes = async () => (await API.get("/quizzes")).data;
export const addQuiz = async (data) => (await API.post("/quizzes", data)).data;
export const updateQuiz = async (id, data) => (await API.put(`/quizzes/${id}`, data)).data;
export const deleteQuiz = async (id) => (await API.delete(`/quizzes/${id}`)).data;

//
// ---------- SUBMISSIONS ----------
export const getSubmissions = async () => (await API.get("/submissions")).data;
export const addSubmission = async (data) => (await API.post("/submissions", data)).data;
export const updateSubmission = async (id, data) => (await API.put(`/submissions/${id}`, data)).data;
export const deleteSubmission = async (id) => (await API.delete(`/submissions/${id}`)).data;

//
// ---------- NOTIFICATIONS ----------
export const getNotifications = async () => (await API.get("/notifications")).data;
export const addNotification = async (data) => (await API.post("/notifications", data)).data;
export const updateNotification = async (id, data) => (await API.put(`/notifications/${id}`, data)).data;
export const deleteNotification = async (id) => (await API.delete(`/notifications/${id}`)).data;

//
// ---------- USERS ----------
export const getUsers = async () => (await API.get("/users")).data;
export const addUser = async (data) => (await API.post("/users", data)).data;
export const updateUser = async (id, data) => (await API.put(`/users/${id}`, data)).data;
export const deleteUser = async (id) => (await API.delete(`/users/${id}`)).data;

//
// ---------- PAYMENTS ----------
export const getPayments = async () => (await API.get("/payments")).data;
export const addPayment = async (data) => (await API.post("/payments", data)).data;
export const updatePayment = async (id, data) => (await API.put(`/payments/${id}`, data)).data;
export const deletePayment = async (id) => (await API.delete(`/payments/${id}`)).data;
